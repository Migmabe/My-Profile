<h1>Meal Prep Application</h1>

The Meal Prep Application is a simple Python program that helps you manage your meal preparation by allowing you to enter, delete, search, and display meals along with their ingredients and weights. This application is designed to streamline your meal planning process and generate a shopping list based on your recipes.

<h2>Features</h2>

<h3>1. Enter a Meal</h3>
To enter a meal, choose option 1 and provide the meal's name and the number of ingredients it requires. You can then enter the ingredients and their respective weights in grams. The application will track the ingredients and their weights for each meal.

<h3>2. Delete a Meal</h3>
Option 2 allows you to delete a previously entered meal. Enter the name of the meal you want to remove, and the application will remove it, updating the ingredient list accordingly.

<h3>3. Search a Meal</h3>
Choose option 3 and enter the name of a meal to search for. The application will display the ingredients and weights for that meal if it exists. If the meal is not found, it will inform you.

<h3>4. Sort Meals</h3>
Option 4 sorts your entered meals alphabetically, making it easier to find and manage your recipes.

<h3>5. Display Meals</h3>
Select option 5 to display all your entered meals along with their ingredients and weights. This feature provides an overview of your meal preparation options.

<h3>6. Shopping List</h3>
Option 6 generates a shopping list by displaying all your ingredients along with their weights. This feature helps you compile a list of items you need for your recipes.

<h3>7. Quit</h3>
Option 7 allows you to exit the application when you're done. The application will thank you for using it.

<h2>How It Works</h2>

The Meal Prep Application is based on a few key functions:

- individual: This function allows you to enter a new meal by providing the meal's name, ingredients, and their weights. It also keeps track of each meal and its components in the <i>block</i> list.

- general: The <i>general</i> function handles the addition of ingredients and their weights to the global lists <i>ingredients_general</i> and <i>weights_general</i>. If the ingredient already exists, it updates the weight accordingly.

- main: The <i>main</i> function collects the meal's <i>name</i>, the <i>number of ingredients</i>, and the individual <i>ingredients</i> with their weights.

- deletion: This function removes a meal from the <i>meal_general</i> list and updates the <i>ingredients_general</i>, <i>weights_general</i>, and <i>block</i> lists accordingly.

The program uses a menu-driven interface to provide the user with options for meal management.</p>

<h2>Getting Started</h2>

1. Run the program, and the main menu will prompt you with various options.

2. Select the desired option by entering the corresponding number.

3. Follow the prompts to enter meal information, search for meals, delete meals, or perform other actions.

4. Review the results and use the Meal Prep Application to manage your meals and generate a shopping list.

<h2>Note</h2>

- To exit the application, select option 7, and the program will display a thank-you message and terminate.

- The application is designed to help you manage meals efficiently. You can continually update and interact with it as you plan your meals.

- The application is not case sensitive and all the user input will be capitalized for better readability.

- Please ensure you enter numeric values for ingredients' weights. If a numeric value is not entered, the whole meal entry will be erased.

Enjoy your meal planning and preparation with the Meal Prep Application!
