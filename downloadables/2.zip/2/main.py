"""
This main script will perform all the operations outlined in the assignment description:

1. Enter 5 records: in this case meals
2. Delete and search records based on string entry
3. Sort records alphabetically and display them
4. Select an option on the screen and perform a function: this program has 7 options
5. Get a prompt on the screen before a function is performed

Please consider having a look at the README file appended to this program.

Feel free to fork a copy of this program for personal use. Citation not mandatory but greatly appreciated.

Have fun using the MEAL PREP APP!!

Miguel Maide Bezares October 2023.
Student ID 12694153
Assignment 1: Part 2
Launching into Computer Science
"""

# List and variable initialization

meal_general = []
ingredients_general = []
weights_general = []
block = []
meal_general_length_before = 0
meal_general_length_after = 0
ingredients_meal_length_after = 0
weights_meal_length_after = 0
meal_general_length_after_2 = 0
meal_general_length_before_2 = 0
weight = 0
ingredients_number = 0


def individual(name_of_recipe, ingredients_meal, weights_meal):

    """This function builds the block list and nested lists with the meal name and its respective ingredients +
    quantities. Called after the main function to update the block list simultaneously."""

    # Addition block initializes the nested list

    addition_block = []
    addition_block.append(name_of_recipe)

    # After adding the name in position 0 of the nested list, the ingredient and total weight are appended in the same
    # cell

    for i in ingredients_meal:
        addition_block.append(i + " " + str(weights_meal[ingredients_meal.index(i)]))

    block.append(addition_block)

    return block

def general(ingredient, weight):

    """This function adds the weight quantities of repeated ingredients onto the general weights list, to avoid
    repetitions when generating the shopping list"""

    # position of the ingredient = position of its respective weight on the other list

    locator = ingredients_general.index(ingredient)

    # initial weight (already in list)

    w = weights_general[locator]

    # add the weight in the same position using a bit of slicing manipulation

    weights_general[locator] = f"{int(w[0:(len(w)-1)]) + weight}g"


def main(name_of_recipe, number_of_ingredients):

    """This function manipulates the ingredients and weights general lists by taking user input."""

    global ingredients_meal, weights_meal, meal_general_length_before, meal_general_length_after, ingredients_meal_length_after, weights_meal_length_after, weight

    try:

        meal_general_length_before = len(meal_general)

        meal_general.append(name_of_recipe)

        ingredients_meal = []
        weights_meal = []

        for k in range(number_of_ingredients):

            ingredient = input("Enter ingredient: ").upper().replace(" ","_")
            weight = int(input("How much of that ingredient do you need in grams?\n"))

            ingredients_meal.append(ingredient)
            weights_meal.append(f"{weight}g")

            # check if the mentioned ingredient is already in the general list. If not, add it.

            if ingredient in ingredients_general:
                general(ingredient,weight)
            else:
                ingredients_general.append(ingredient)
                weights_general.append(f"{weight}g")

        meal_general_length_after = len(meal_general)
        ingredients_meal_length_after = len(ingredients_meal)
        weights_meal_length_after = len(weights_meal)
        individual(name_of_recipe, ingredients_meal, weights_meal)

    except:
        meal_general.pop()
        weight_exception(ingredients_meal, weights_meal)
        print("Weight must be a whole number.")
        return None

def deletion(x):

    """This function is a helper function to the 3 main functions. It modifies ingredients_general = []
    weights_general = [] and block = []"""

    global meal_general_length_before_2, meal_general_length_after_2

    # Testing var declaration inside the function. Before and after declared to check if after actually changes or
    # stays the same

    meal_general_length_before_2 = len(meal_general)
    meal_general_length_after_2 = len(meal_general)

    if x in meal_general:

        meal_general.remove(x)

        for sublist in block:
            if x in sublist:
                block.remove(sublist)
                for ing in sublist[1:]:
                    # This nested list will split the ingredient and the weight to handle them separately
                    nested = ing.split(" ")
                    a = nested[1]
                    locator = ingredients_general.index(nested[0])
                    b = weights_general[locator]
                    if int(b[0:len(b)-1]) == int(a[0:len(a)-1]):
                        weights_general.remove(weights_general[locator])
                        ingredients_general.remove(nested[0])
                    else:
                        weights_general[locator] = f"{int(b[0:len(b)-1])-int(a[0:len(a)-1])}g"

        meal_general_length_after_2 = len(meal_general)

        return "Meal successfully deleted."

    else:
        return "The meal name entered could not be found."

def weight_exception(ingredients_list, weights_list):

    for _ in ingredients_list:

        locator = ingredients_list.index(_)
        locator2 = ingredients_general.index(_)
        # Weight of the current meal ingredient in general (it must be >= ingredient in meal)
        a = weights_general[locator2]
        # Weight of the meal ingredient
        b = weights_list[locator]
        if a == b:
            weights_general.pop()
            ingredients_general.pop()
        else:
            weights_general[locator2] = f"{a - b}g"

while True:

    # Check if sorting operation is available, fed to testing.pyy

    if block:
        sorting = bool(1)

    print("Welcome to the Meal Prep Application!")
    print(" 1. Enter a meal.")
    print(" 2. Delete a meal.")
    print(" 3. Search a meal.")
    print(" 4. Sort meals.")
    print(" 5. Display mode.")
    print(" 6. Shopping List.")
    print(" 7. Quit")

    try:

        option = int(input("Please choose an option from the menu from 1 to 7:\n"))

        if option == 1:

            name = input("Whats the name of your recipe?\n").upper()
            ingredients_number = int(input("How many ingredients do you need?\n"))
            main(name, ingredients_number)

        elif option == 2:
            to_delete = input("What recipe would you like to delete?\n").upper()
            print(deletion(to_delete))

        elif option == 3:

            look_up = input("What meal do you want to search for?\n").upper()
            for sublist in block:
                if look_up in sublist:
                    print(sublist)
                else:
                    print("The meal you entered cannot be found.")

        elif option == 4:
            try:
                # For testing, try sorting, if cannot, then except False to feed to testing.py
                if len(block) == 0:
                    float("")
                block.sort()
                sorting = bool(1)
                print("Meals sorted alphabetically.")
            except:
                sorting = bool(0)

        elif option == 5:

            print(block)

        elif option == 6:

            for n in range(len(ingredients_general)):

                print(f"{ingredients_general[n]}, {weights_general[n]}")

        elif option == 7:

            print("Thanks for using the Meal Prep App!")
            break

        else:

            print("Please enter a number from 1 to 7.")

    except ValueError:

        print("Invalid choice.")



