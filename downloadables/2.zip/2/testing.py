"""
This script is a secondary script its purpose is to test and maintain the main script. It is recommended the user runs
the main script with the testing file first to make sure all the inputs were right. The testing script will let the user
know what to enter on every prompt if the entered input was invalid.

Findings were retrofitted into the main script while producing the file. For example, the try block was implemented in
the main function to avoid errors in case the entered weight was not a whole number.

HOW TO USE THIS FILE?

1. Run the testing script and perform several actions on main
2. Exit the main script by selecting option 7
3. You're in the testing environment!

A few things will be tested including list length, operations (sort, delete and search) verification and variable
ranges. For example, a weight of 0 is not a valid weight, so weight must be >= 1g.

Miguel Maide Bezares October 2023.
Student ID 12694153
Assignment 1: Part 2
Launching into Computer Science
"""

from main import meal_general_length_before, meal_general_length_after, ingredients_meal_length_after, weights_meal_length_after, sorting, meal_general_length_before_2, meal_general_length_after_2, weight, ingredients_number

def calcs():

    error_messages = []

    if not meal_general_length_before < meal_general_length_after:
        error_messages.append("New meal not added properly.")

    if not ingredients_meal_length_after > 0:
        error_messages.append("Individual ingredients were not properly added.")

    if not weights_meal_length_after > 0:
        error_messages.append("Individual weights were not properly added.")

    if not sorting is True:
        error_messages.append("Sorting operation could not be performed. List is either wrong or empty.")

    if meal_general_length_before_2 >= meal_general_length_after_2:
        error_messages.append("Deletion did not work as expected, check meal name.")

    if weight <= 0:
        error_messages.append("Ingredient must be a positive whole number.")

    if ingredients_number <= 0:
        error_messages.append("The number of ingredients used must be 1 or more.")

    if error_messages:
        for message in error_messages:
            print(message)
        return 0

while True:

    print("1. Run tests.")
    print("2. Exit tests.")

    try:
        option = int(input("Please choose option: 1 or 2:\n"))
        if option == 1:

            if calcs() == 0:
                print()
                print("Not all tests passed.\n",end='\n')
            else:
                print("All tests passed.")

        elif option == 2:

            break

        else:
            print("Please enter 1 or 2.")
    except:

        print("Please enter a numeric value 1 or 2.")
